import { initializeApp } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";

import {
  getAuth,
  RecaptchaVerifier,
  signInWithPhoneNumber
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCNR1EBQAJLIY3sz9-2jgT72_Sf7eE4a7I",
  authDomain: "my-social-media-45f52.firebaseapp.com",
  projectId: "my-social-media-45f52",
  storageBucket: "my-social-media-45f52.firebasestorage.app",
  messagingSenderId: "441505615713",
  appId: "1:441505615713:web:18cf7eec24a984e43c3f20",
  measurementId: "G-S9ZDTR0L9S"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

window.recaptchaVerifier = new RecaptchaVerifier(auth, "recaptcha-container", {
  size: "normal"
});

document.getElementById("sendOtp").addEventListener("click", async () => {

  const phone = document.getElementById("phone").value;

  try {

    const confirmation =
      await signInWithPhoneNumber(
        auth,
        phone,
        window.recaptchaVerifier
      );

    window.confirmationResult = confirmation;

    document.getElementById("status").innerHTML =
      "OTP Sent Successfully";

  } catch (err) {

    document.getElementById("status").innerHTML =
      err.message;

  }

});

document.getElementById("verifyOtp").addEventListener("click", async () => {

  const otp = document.getElementById("otp").value;

  try {

    await window.confirmationResult.confirm(otp);

    document.getElementById("status").innerHTML =
      "Login Successful";

  } catch {

    document.getElementById("status").innerHTML =
      "Invalid OTP";

  }

});